export { MonolithTemplate } from './MonolithTemplate'
