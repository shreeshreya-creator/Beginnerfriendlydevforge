export { TerminalTemplate } from './TerminalTemplate'
